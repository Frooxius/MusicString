#include "AudioGen.h"

namespace MusStr
{
	AudioGen::AudioGen(uint sampleRate,
		uint bufsize)
	{
		this->sampleRate = sampleRate;
		this->bufsize = bufsize;
		this->intern_buf_pos = bufsize;

		// create internal buffer
		intern_buffer = new float[bufsize];
		next_update = 0;	// update right away (when it's called)
	}

	bool AudioGen::Append(list<string> *appendlist, bool autodelete)
	{
		// append it
		muslist.insert(muslist.end(), appendlist->begin(),
			appendlist->end());

		if(autodelete)
			delete appendlist;

		// calculate if there's enough items to fill whole internal buffer
		return UpdateWarningItems();
	}

	uint AudioGen::Generate(float *buffer, uint samples, bool finalize)
	{
		uint generated = 0;
		bool breakout = false;
		while(samples)
		{
			for(; samples && (intern_buf_pos != bufsize);
				samples--, intern_buf_pos++, generated++)
				*(buffer+generated) = *(intern_buffer+intern_buf_pos);

			// need more MusicList data
			if(breakout && !finalize)
				break;

			// it's basically done
			if(generators.empty() && muslist.empty())
				break;

			if(intern_buf_pos == bufsize)
				// need to refill the buffer
				breakout = !FillInternBuff();
		}

		return generated;
	}

	list<string> AudioGen::GetTones()
	{
		list<string> tones;
		string temp = muslist.front();

		temp = temp.substr(temp.find('-')+1);
		while(temp.find(';') != temp.npos)		
		{
			tones.push_back(
				temp.substr(0, temp.find(';')));
			temp = temp.substr(temp.find(';')+1);
		}

		return tones;
	}

	float AudioGen::GetTime(const string &str)
	{
		// simply convert the first number in the string
		return FromString<float>(str);
	}

	bool AudioGen::UpdateWarningItems()
	{
		uint samples = 0;
		warning_items = 0;
		// start at the end and go back
		for(list<string>::reverse_iterator i = muslist.rbegin();
			i != muslist.rend(); i++)
		{
			samples += (uint)(GetTime(*i)*sampleRate);
			warning_items++;

			if(samples >= bufsize)
				break;
		}
		if(samples < bufsize)
			return false;
		else
			return true;
	}

	bool AudioGen::FillInternBuff()
	{
		float *tempbuf = new float[bufsize];

		// reset the position
		intern_buf_pos = 0;

		// clean up buffer first
		for(uint i = 0; i < bufsize; ++i)
			*(intern_buffer+i) = 0.0f;

		uint offset = 0, remaining = bufsize, generated = 0;
		do
		{
			// calculate how much is going to be generated in this step
			generated = Min(next_update, remaining);
			next_update -= generated; // subtract how much is going to be generated

			// Go trough all the generators and generate audio
			for(list<GenItem>::iterator i = generators.begin();
				i != generators.end(); ++i)
			{
				i->active = i->gen->Generate(tempbuf+offset, generated);
				// add the data
				for(uint i = 0; i < generated; ++i)
					*(intern_buffer+offset+i) += *(tempbuf+offset+i);
			}

			// caltulate how much was generated and new offset and such
			offset += generated;
			remaining -= generated;

			// remove finished generators
			for(list<GenItem>::iterator i = generators.begin();
				i != generators.end(); ++i)
			{
				bool repeat;
				do
				{
					repeat = false;
					if(!i->active)
					{
						delete i->gen;
						i = generators.erase(i);
						if(i != generators.end())
							repeat = true;
					}
				} while(repeat);

				if(i == generators.end())
					break;
			}

			if(remaining)
				if(!LoadNextItem())
					break;
		} while(remaining);

		// cleanup
		delete tempbuf;

		return muslist.size() > warning_items;
	}

	bool AudioGen::LoadNextItem()
	{
		if(muslist.empty())
			return false;

		next_update = (uint)(GetTime(muslist.front())*sampleRate);
		list<string> tones = GetTones();
		// remove the front entry
		muslist.pop_front();
		// go trough all the ones and make generators from them
		for(list<string>::iterator i = tones.begin();
			i != tones.end(); ++i)
			generators.push_back(
				GenItem(new Generator(Tone(*i), sampleRate))); 

		return true;
	}
}#include <string>
#include <list>
#include "Utility.h"
#include "Generator.h"

using namespace std;

namespace MusStr
{
	class AudioGen
	{
		struct GenItem
		{
			Generator *gen;
			bool active;
			GenItem(Generator *gen) { this->gen = gen; active = true; }
		};

		list<string> muslist;
		list<GenItem> generators;
		uint sampleRate,
			 bufsize;

		float *intern_buffer;
		uint intern_buf_pos;
		uint next_update;
		uint warning_items;

		bool UpdateWarningItems();

		bool LoadNextItem();
		// gets a list of tones from a single line
		list<string> GetTones();
		// get time of the next tone
		float GetTime(const string &str);

		bool FillInternBuff();

	public:
		AudioGen(uint sampleRate, uint bufsize = 512);

		bool Append(list<string> *appendlist, bool autodelete = false);
		
		uint Generate(float *buffer, uint samples, bool finalize = false);
	};
}#pragma once
#include "Utility.h"
#include <string>

// Very basic exception
class Exception
{
	std::string msg;	// the message
	uint code;	// error message code

protected:
	void Append(std::string app)
	{
		msg += app;
	}

public:
	Exception(const char *msg, uint code)
	{
		this->msg = msg;
		this->code = code;
	}

	uint GetCode() { return code; }
	const char *GetMsg() { return msg.c_str(); }
};
#include "Generator.h"

namespace MusStr
{
	Generator::Generator(Tone tone, uint samplerate)
	{
		this->tone = tone;
		this->samplerate = samplerate;

		softnoise = 0.0f;
		noiseval = frand()*0.5f;
		nextchange = 1.0f;

		// caculate the angular step
		angle = 0;
		angular_step = (2.0*PI*tone.GetFreq())/(double)this->samplerate;

		// caculate how many samples need to be rendered
		gen_samples = (uint)(samplerate*(double)tone.GetDuration());
		gen_sample = 0;
	}

	// Noise
	float Generator::noise(float r)
	{
		r = 1.0f-r;

		if(abs(nextchange) < 0.1f)
		{
			nextchange = 1.0f;
			noiseval = frand()*0.25f;
		}

		nextchange *= r;
		softnoise += noiseval;

		if(softnoise > 1.0f)
		{
			softnoise = 1.0f - frac(softnoise);
			noiseval = -abs(noiseval);
		}
		else if(softnoise < -1.0f)
		{
			softnoise = -1.0f + frac(softnoise);
			noiseval = abs(noiseval);
		}

		return softnoise;
	}

	float Generator::Amplitude()
	{
		return tone.GetVolume() *
			tone.GetShape(gen_sample/(float)gen_samples) *
			Min(1.0f, (gen_samples-gen_sample)/100.0f); // small fadeout
	}

	bool Generator::Generate(float *buffer, uint samples)
	{
		for(uint i = 0; i < samples; ++i)
		{
			*(buffer+i) = Signal(angle)*Amplitude();
			angle += angular_step;
			gen_sample++;
		}

		if(gen_sample >= gen_samples)
			return false;
		else
			return true;
	}

	float Generator::Signal(double angle)
	{
		switch(tone.GetWaveForm())
		{
		case waveSine:
			return (float)sin(angle);
		case waveTriangle:
			return triangle(angle);
		case waveSawtooth:
			return sawtooth(angle);
		case waveSquare:
			return square(angle);
		case waveNoise:
			return noise(tone.GetFreq()/5000.0f);
		case wavePluck:
			return ( square_flat(angle)*noise(gen_sample/(float)(gen_samples)) )
				*exp(-(gen_sample/(float)(gen_samples))*4.0f)*2.0f;
		}

		return 0.0f;	// flatlineeeee.....................
	}
}#include "Tone.h"
#include <cmath>
#include <cstdlib>

using namespace std;

namespace MusStr
{
	class Generator
	{
		float softnoise, nextchange, noiseval;
		float flat_rand() { return rand()/(float)RAND_MAX; }
		float frand() { return flat_rand()*2.0f - 1.0f; }
		float noise(float r);
		float frac(float n) { return abs(n-(int)n); }

		float sawtooth(double angle) { return (float)(-1.0f + 2.0f*((angle/PI_HALF)-(uint)(angle/PI_HALF))); }
		float triangle(double angle) { return (float)(asin(sin(angle))/PI_HALF); }
		float square(double angle) { return (float)((sin(angle)>0.0)?1.0f:-1.0f); }
		float square_flat(double angle) { return (float)((sin(angle)>0.0)?1.0f:0.0f); }

	protected:
		Tone tone;
		uint samplerate;
		uint gen_samples;
		uint gen_sample;
		double angular_step,
			   angle;
		//virtual void GenData(float *buffer, uint samples);

		inline float Amplitude();
		inline float Signal(double angle);

	public:
		Generator(Tone tone, uint samplerate);

		// returns false if it's finished
		bool Generate(float *buffer, uint samples);
	};
}#include "MStr2Audio.h"
#include <fstream>
#include <iostream>
#include <string>

using namespace MusStr;

struct wavfile
{
    char        id[4];          // should always contain "RIFF"
    int     totallength;    // total file length minus 8
    char        wavefmt[8];     // should be "WAVEfmt "
    int     format;         // 16 for PCM format
    short     pcm;            // 1 for PCM format
    short     channels;       // channels
    int     frequency;      // sampling frequency
    int     bytes_per_second;
    short     bytes_by_capture;
    short     bits_per_sample;
    char        data[4];        // should always contain "data"
    int     bytes_in_data;
};

int main(int argc, char *argv[])
{
	cout << "MusicString to WAV compiler, v0.2.1a, by Frooxius (http://frooxius.solirax.org)"
		<< endl << "--------------------------------------------" << endl;

	if(argc != 2)
	{
		cout << "Wrong arguments!" << endl
			<< "Usage: musstr input.mstr" << endl;
		return 1;
	}

	// Load the file
	fstream input(argv[1], ios::in);
	if(!input)
	{
		cout << "Error: Can't open the input file!" << endl;
		return 1;
	}

	char temp[1024];
	string musstr;
	// load all contents to the string
	while(!input.eof())
	{
		input.getline(temp, 1024);
		musstr += temp;
	}
	input.close();

	float *buf = new float[48000*60*30];

	cout << "Parsing... ";
	cout.flush();
	MStr2Audio gen = MStr2Audio(musstr, 48000);
	cout << "Generating... ";
	cout.flush();

	int num;
	try
	{
		num = gen.Generate(buf, 48000*60*30);
	}
	catch(MusicStringException e)
	{
		cout << "ERROR!" << e.GetMsg();
		return 1;
	}

	string name = string(argv[1]).substr(
		0, string(argv[1]).find_last_of('.')) + ".wav";

	cout << "Saving... ";
	cout.flush();
	short *pcmbuf = new short[48000*60*30];
	for(int i = 0; i < 48000*60*30; ++i)
		*(pcmbuf+i) = (short) ((*(buf+i))*0x7FFF);
	fstream file(name.c_str(), std::ios::out | std::ios::binary);

	// wav header
	wavfile header;
	header.bits_per_sample = sizeof(short)*8;
	header.bytes_by_capture = sizeof(short);
	header.bytes_in_data = num*sizeof(short);
	header.bytes_per_second = 48000*sizeof(short);
	header.channels = 1;
	header.data[0] = 'd';
	header.data[1] = 'a';
	header.data[2] = 't';
	header.data[3] = 'a';
	header.format = 16;
	header.frequency = 48000;
	header.id[0] = 'R';
	header.id[1] = 'I';
	header.id[2] = 'F';
	header.id[3] = 'F';
	header.pcm = 1;
	header.totallength = num*sizeof(short)+sizeof(header)-8;
	for(int i = 0; i < 8; ++i)
		header.wavefmt[i] = "WAVEfmt "[i];

	file.write((char *)&header, sizeof(header));
	file.write((char *)pcmbuf, sizeof(short)*num);

	file.close();

	cout << "Done! Happy listening! >:3" << endl;
}#include "MStr2Audio.h"

namespace MusStr
{
	MStr2Audio::MStr2Audio(string musstr, uint samplerate)
	{
		mstr = new MusicString(musstr);
		agen = new AudioGen(samplerate);
	}

	uint MStr2Audio::Generate(float *buf, uint samples)
	{
		// keep on generating, until the MusicString is done (if even...)
		bool finalize = false;
		uint generated = 0;

		while((samples-generated) && !finalize)
		{
			// generate music list until it's enough for the generatator
			while(!agen->Append(mstr->GenMusicList(50), true)
				&& !finalize)
				finalize = mstr->Done();

			generated +=
				agen->Generate(buf+generated, samples-generated, finalize);			
		}

		return generated;
	}
}#include "MusicString.h"
#include "AudioGen.h"
#include "Utility.h"

namespace MusStr
{
	/*
		This class handles converting MusicString to raw audio
		data.
	*/
	class MStr2Audio
	{
		MusicString *mstr;
		AudioGen *agen;

	public:
		MStr2Audio(string musstr, uint samplerate = 44100);

		// will generate audio and return how many samples were generated
		uint Generate(float *buf, uint samples);
	};
}#include "MusicString.h"

namespace MusStr
{
	bool DeleteThread(MusicStringThread *t)
	{
		if(t->Finished())
		{
			delete t;
			return true;
		}
		return false;
	}

	MusicString::MusicString(string musstr)
	{
		this->musstr = musstr;
		InitParse();

		newthread_elapsed = (float)FINF;
		// initialize first thread
		threads.push_back(new Thread(&this->musstr, this));
	}

	string MusicString::GetLine()
	{
		list<Tone> tones;	// all the tones for a single line

		float following_update = (float)FINF;

		do
		{
			// generate tones from all threads that are due to update
			for(list<Thread*>::iterator i = threads.begin();
				i != threads.end(); i++)
			{
				if((*i)->NextUpdate() == 0.0f || isinf((*i)->NextUpdate()))
				{
					(*i)->Tick();
					
					// thread generated something
					if((*i)->Active())
						tones.push_back(
						(*i)->GetLastTone());
				}
			}

			// delete all threads marked for deletion
			threads.remove_if(DeleteThread);

			// find next update time
			for(list<Thread*>::iterator i = threads.begin();
				i != threads.end(); i++)
				following_update = Min(following_update, (*i)->NextUpdate());

			// shift all of them to the next update
			for(list<Thread*>::iterator i = threads.begin();
				i != threads.end(); i++)
				(*i)->NextUpdate(following_update);

		} while(tones.empty() && !threads.empty());

		// it's last in the list
		if(isinf(following_update))
		{
			following_update = 0.0f;
			for(list<Tone>::iterator i = tones.begin();
				i != tones.end(); i++)
				following_update = 
					Max(i->GetDuration(), following_update);
		}

		string line = ToString(following_update) + " - ";

		for(list<Tone>::iterator i = tones.begin();
				i != tones.end(); i++)
			line += i->GetMusicListEntry();

		return line;
	}

	list<string> *MusicString::GenMusicList(int maxlines)
	{
		list<string> *muslist = new list<string>();

		for(; maxlines > 0 && !Done(); maxlines--)
 			muslist->push_back(GetLine());

		return muslist;
	}

	void MusicString::InitParse()
	{
		// Look for subroutine definitions
		int openpos = -1;
		bool openscan = false;
		string subname;
		for(uint p = 0; p < musstr.length(); ++p)
		{
			char ch = musstr[p];
			// beginning is found
			if(ch == '{' && !openscan)
			{
				// start scanning if it's a subroutine or not
				subname = "";
				openscan = true;
				openpos = p;
				continue;
			}
			if(openscan)
			{
				if((isalpha(ch) || isdigit(ch)))
					subname += ch;
				else if(ch == ';')
				{
					/*  first overwrite opening with special symbol
						so the definition is ignored when further
						parsing the code when generating tones */
					musstr[openpos] = (char)SUBR_SKIP_CHAR;

					int begin = ++p;
					int depth = 1;
					for(; p < musstr.length(); ++p)
					{
						ch = musstr[p];
						if(ch == '{')
							depth++;
						if(ch == '}')
							depth--;
						if(!depth)
						{
							// found end of the subroutine body
							subroutines.insert(
								pair<string, StrRange>(subname,
									StrRange(begin, p-1)));
							openscan = false;
							break;
						}
					}
				} else
				{
					// it's not a subroutine definition, discard
					openscan = false;
				}
			}
		}
	}

	void MusicString::InsertThread(MusicStringThread *mt, bool wait)
	{
		threads.push_back(mt);
	}

	void MusicString::StopLoop(string name)
	{
		for(list<Thread*>::iterator i = threads.begin();
				i != threads.end(); i++)
		{
			if((*i)->GetName() == name)
				(*i)->TerminateLoop();
		}
	}

	StrRange MusicString::GetSubroutinePos(string name)
	{
		map<string, StrRange>::iterator i =
			subroutines.find(name);
		if(i == subroutines.end())
			throw MusicStringException(ERR_MUSSTR_SUB_NOT_FOUND,
			"Name: " + name);
		return i->second;
	}
}#pragma once
#include <string>
#include <list>
#include <map>
#include "MusicStringThread.h"
#include "Tone.h"
#include "Utility.h"

using namespace std;

namespace MusStr
{
	struct StrRange
	{
		int posb, pose;
		StrRange() { posb = pose = -1; }
		StrRange(int posb, int pose)
		{
			this->posb = posb;
			this->pose = pose;
		}
	};

	class MusicString
	{
	private:
		typedef MusicStringThread Thread;

		string musstr;			// the music string that's being processed 

		list<Thread*> threads;				// all the threads
		map<string, StrRange> subroutines;	// isn't this self explanatory? -_-

		float newthread_elapsed;

		void InitParse();		// must be called first, does the first pass parsing
		string GetLine();		// get a single line

	public:
		MusicString(string musstr);

		// Interacting with threads
		void InsertThread(MusicStringThread *mt, bool wait);
		void StopLoop(string name);

		string GetSoundfontList();
		list<string> *GenMusicList(int maxlines);

		// Getting info, mostly for threads
		StrRange GetSubroutinePos(string name);

		bool Done() { return threads.empty(); }
	};
}#include "MusicStringException.h"

namespace MusStr
{
	const char *StrMusicString_Exception[] =
	{
		"Chord contains empty argument",
		"Subroutine has too many arguments",
		"Subroutine doesn't exist",
		"Loop contains empty parts",
		"Loop contains too many parts",

		"INTERNAL"
	};
}#pragma once
#include "Exception.h"

namespace MusStr
{
	enum eMusicStringException
	{
		ERR_MUSSTR_CHORD_EMPTY_ARG,
		ERR_MUSSTR_SUB_TOO_MANY_ARGS,
		ERR_MUSSTR_SUB_NOT_FOUND,
		ERR_MUSSTR_LOOP_EMPTY_PART,
		ERR_MUSSTR_LOOP_TOO_MANY_PARTS,

		INFO_MUSSTR_THREAD_FINISHED

	};

	extern const char *StrMusicString_Exception[];

	class MusicStringException : protected Exception
	{
	public:
		MusicStringException(eMusicStringException exception, std::string append = "") : 
			Exception(StrMusicString_Exception[(uint)exception], (uint)exception)
			{
				if(append.length())
				Append(append);
			}

			eMusicStringException GetCode() { 
				return (eMusicStringException)Exception::GetCode(); }
			const char *GetMsg() { return Exception::GetMsg(); }
	};
}#include "MusicStringThread.h"
#include "MusicString.h"	// cross dependency
#include "Tone.h"

namespace MusStr
{
	MusicStringThread::MusicStringThread(string *musstr,
	class MusicString *owner, int pos, int epos, ThreadStatus *status,
		MusicStringThread *parent, int repeat, string name)
	{
		this->lastTickGenerated = false;
		this->finished = false;

		this->musstr = musstr;
		this->bpos = this->pos = pos;
		this->epos = epos;
		this->owner = owner;
		this->repeat = repeat;
		this->name = name;

		this->waiting = 0;
		this->nextUpdate = 0.0f; // new threads are updated right way

		// copy the status if provided (it's a child thread)
		if(status)
			this->status = *status;
		else
		{
			// initialize the arguments
			this->status.bpm = 120.0f;
			this->status.duration = note4th;
			this->status.nshift = 0;
			this->status.soundfont = "0";
			this->status.volshape = volLinear;
			this->status.volume = 0.2f;
			this->status.wave = waveSine;
			for(int i = 0; i < 32; ++i)
				this->status.args[i] = Argument();
		}

		// set the parent thread (might be NULL, that's okay)
		this->parent = parent;
	}

	MusicStringThread::~MusicStringThread()
	{
		if(parent)
			parent->SubthreadDone(nextUpdate);
	}

	void MusicStringThread::Tick()
	{
		// nothing to do
		if(finished)
			return;

		nextUpdate = FINF;

		while(isinf(nextUpdate) && !waiting && !finished)
			nextUpdate = ProcessChar(GetChar());

		lastTickGenerated = !isinf(nextUpdate);
	}

	void MusicStringThread::SubthreadDone(float nextUpdate)
	{
		waiting--;
		if(isinf(this->nextUpdate))
			this->nextUpdate = nextUpdate;
		else
			this->nextUpdate = Max(nextUpdate, this->nextUpdate);
	}

	char MusicStringThread::GetChar(bool evalarg)
	{
		char ch;	// char to be returned

		do
		{
			// first, do buffer cleanup
			while((buffer.size() != 0) && (buffer.top().Empty() ))
					buffer.pop();

			if(buffer.empty())
			{
				if( ((pos == epos) && (epos != -1)) || pos == musstr->length()-1)
				{
					if(--repeat == 0)
						finished = true;
					else
					{
						// reset it
						pos = bpos;
						if(repeat < 0)
							repeat = 0;
					}
				}
				lastpos = pos;
				ch = (*musstr)[pos++];
			}
			else
			{
				lastpos = buffer.top().p++;
				ch = (*musstr)[lastpos];
			}

			if((ch == '$') && evalarg)
			{
				LoadArg();
				ch = GetChar();
			}
		} while((ch > 0) && isspace(ch));	// skip all whitespace characters

		return ch;
	}

	void MusicStringThread::LoadArg()
	{
		char ch = tolower(GetChar());
		int index = -1;

		// convert ch to index and then load it
		if(isdigit(ch))
			index = ch-'0';

		if(isalpha(ch))
			index = ch-'a' + 10;

		if(index != -1)
			buffer.push(status.args[index]);
	}

	float MusicStringThread::ProcessChar(char ch)
	{
		/* Must test high ASCII characters first, because
		standard library functions do bollocks when it's apssed
		to them */
		if(ch == (char)SUBR_SKIP_CHAR)
			SkipSubroutineDefinition();
		else if(isalpha(ch))
			return GenTone(ch);
		else if(ch == '.')
			return GenPause();
		else if(isalnum(ch))
			SetDuration(ch);
		else if(ch == '(')
			LoadChord();
		else if(ch == '{')
			LoadSubroutine();
		else if(ch == '[')
			LoadLoop();
		else if(ch == '&')
			PerformShift();
		else if(ch == '@')
			LoadBpm();
		else if(ch == '#')
			LoadSoundfont();
		else if(ch == '%')
			LoadVolume();
		else if(ch == '?' || ch == '!')
			EvaluateCondition(ch);
		else if(
			ch == '~' ||
			ch == '/' ||
			ch == '-' ||
			ch == '|' ||
			ch == '^' ||
			ch == '*')
			SetWaveform(ch);
		else if(
			ch == '=' ||
			ch == '<' ||
			ch == '>')
			SetVolumeShape(ch);
		else 
			SkipSubroutineDefinition();

		return FINF;
	}

	int MusicStringThread::CalcN(char letter, char center)
	{
		return (tolower(letter)-(int)'a')*2
            + (bool)isupper(letter) -
            (tolower(center)-'a')*2 - (bool)isupper(center);
	}

	float MusicStringThread::GenTone(char note)
	{
		// first, compute the base n
		int n = CalcN(note, 'n');

		// now add the shift
		n += status.nshift;

		// calculate the frequency
		float f = pow(2.0f, n/12.0f)*440.0f;

		// calculate duration
		float d = pow(2.0f, status.duration - note4th)
			* (1.0f/(status.bpm/60.0f));

		// create new note
		tone = Tone(f, d, status.volume, status.wave,
			status.volshape, status.soundfont, pos-1);

		return d;
	}

	float MusicStringThread::GenPause()
	{
		// calculate duration
		float d = pow(2.0f, status.duration - note4th)
			* (1.0f/(status.bpm/60.0f));

		tone = Tone(0.0f, d, 0.0f, status.wave,
			status.volshape, status.soundfont, pos-1);

		return d;
	}

	void MusicStringThread::SetDuration(char dur)
	{
		status.duration = (NoteDuration)(dur-'0');
	}

	void MusicStringThread::LoadChord()
	{
		// load all parts and create respective threads
		int beginpos = -1, endpos = -1;
	
		int depth = 1;	// in case there are any nested
		do
		{
			char ch;
			endpos = GetPos();
			switch(ch = GetChar(false))
			{
			case '[':
			case '{':
			case '(':
			case (char)SUBR_SKIP_CHAR:
				depth++;
				break;
			case ']':
			case '}':
			case ')':
				depth--;

				if(depth != 0)
					break;
				// fall trough if it's existinng - there's still argument
			case ',':
				if(depth <= 1)
				{
					if(beginpos != -1)
					{
						MusicStringThread *mt = new MusicStringThread(
							musstr, owner, beginpos, endpos,
							&status, this);
						owner->InsertThread(mt, lastTickGenerated);
						waiting++;
						beginpos = -1;	// reset it
					}
					else
					{
						throw MusicStringException(
							ERR_MUSSTR_CHORD_EMPTY_ARG,
							"At pos: " + ToString(GetPos()));
					}
				}
				break;
			}
			if(beginpos == -1 && ch != ',')
				beginpos = GetPos();
		} while(depth);
	}

	void MusicStringThread::LoadSubroutine()
	{
		// load the subroutine name first

		char ch;
		string subname;
		while((ch = GetChar()) != ':')
			subname += ch;

		// fetch the subroutine position from the owner
		StrRange sub = owner->GetSubroutinePos(subname);
		ThreadStatus newstatus = status;

		// load the arguments
		int depth = 1, argn = 0, beginpos = -1, endpos = -1;
		do
		{
			char ch;
			endpos = GetPos();
			switch(ch = GetChar())
			{
			case '[':
			case '{':
			case '(':
			case (char)SUBR_SKIP_CHAR:
				depth++;
				break;				
			case ']':
			case '}':
			case ')':
				depth--;

				// if there's still some part, load it
				if(depth)
					break;

			case ',':
				if(depth > 1)
					break;

				if(beginpos != -1)
				{
					// set the argument
					newstatus.args[argn] = Argument(beginpos, endpos);
					beginpos = -1; // rest it again
				}
				argn++;	// empty arguments are simply skipped

				if(argn == 32)
					throw MusicStringException(
						ERR_MUSSTR_SUB_TOO_MANY_ARGS);

				break;
			}
			if(beginpos == -1 && ch != ',')
				beginpos = GetPos();

		} while(depth);

		// make new thread
		MusicStringThread *mt = new MusicStringThread(
			musstr, owner, sub.posb, sub.pose,
			&newstatus, this);

		waiting++;
		owner->InsertThread(mt, lastTickGenerated);
	}

	void MusicStringThread::LoadLoop()
	{
		// first, determine what kind of statement it is
		StrRange part[3];

		int beginpos = -1, endpos = -1, p = 0, depth = 1;
		do
		{
			char ch;
			endpos = GetPos();
			switch(ch = GetChar(false))
			{
			case '[':
			case '{':
			case '(':
			case (char)SUBR_SKIP_CHAR:
				depth++;
				break;
			case ']':
			case '}':
			case ')':
				depth--;

				// fall trough if there's still some last part
				if(beginpos == -1 || depth != 0)
					break;
			case ':':
				if(depth > 1)
					break;

				if(beginpos == -1)
					throw MusicStringException(
						ERR_MUSSTR_LOOP_EMPTY_PART);

				if(p == 3)
					throw MusicStringException(
						ERR_MUSSTR_LOOP_TOO_MANY_PARTS);

				part[p].posb = beginpos;
				part[p].pose = endpos;
				beginpos = -1;
				p++;
				break;
			}
			if(beginpos == -1 && ch != ':')
					beginpos = GetPos();
		} while(depth);

		// now decide what to do, once all parts are loaded
		string loopname = "";
		int pshift = 0;	// to choose the best part
		if(p == 1 || p == 3)
		{
			// fetch the loop name, strip it from 
            loopname = StripSpaces(musstr->substr(part[0].posb,
                (part[0].pose+1) - part[0].posb));
			pshift = 1;	// first part is name
		}

		if(p == 1)
			owner->StopLoop(loopname);

		if(p == 2 || p == 3)
		{
			owner->InsertThread(new MusicStringThread(
				musstr, owner, part[0+pshift].posb, part[0+pshift].pose,
				&status, this, FromString<int>(musstr->substr(
					part[1+pshift].posb, part[1+pshift].pose)), loopname),
					lastTickGenerated);

			waiting++;
		}
	}

	void MusicStringThread::LoadBpm()
	{
		// read number
		char ch;
		string num;
		while((ch = GetChar()) != ';')
			num += ch;

		// convert it to number
		status.bpm = FromString<float>(num);
	}
	void MusicStringThread::LoadSoundfont()
	{
		// read soundfont
		status.soundfont = "";
		char ch;
		while((ch = GetChar()) != ';')
			status.soundfont += ch;
	}

	void MusicStringThread::LoadVolume()
	{
		char ch = GetChar();	// get volume index
		status.volume = CalcN(ch, 'a')/(float)CalcN('Z', 'a');
		// do some rounding, round doesn't work in VC++ :-/
		status.volume = floor(status.volume*100.0f + 0.5f)/100.0f;
	}

	void MusicStringThread::PerformShift()
	{
		char ch = GetChar();

		status.nshift = 0; // reset it first
		// check if it's halfshift
		if(ch == '-' || ch == '+')
		{
			if(ch == '+')
				status.nshift++;
			else
				status.nshift--;
			ch = GetChar(); // must load following character
		}

		// now translate the character into shift
		status.nshift += CalcN(ch, 'n')*2;
	}

	void MusicStringThread::EvaluateCondition(char type)
	{
		// TODO
	}

	void MusicStringThread::SetWaveform(char wave)
	{
		switch(wave)
		{
		case '~':
			status.wave = waveSine;
			break;
		case '-':
			status.wave = waveSquare;
			break;
		case '^':
			status.wave = waveTriangle;
			break;
		case '/':
			status.wave = waveSawtooth;
			break;
		case '|':
			status.wave = wavePluck;
			break;
		case '*':
			status.wave = waveNoise;
			break;
		}
	}

	void MusicStringThread::SetVolumeShape(char vshape)
	{
		switch(vshape)
		{
		case '=':
			status.volshape = volLinear;
			break;
		case '<':
			status.volshape = volFadeIn;
			break;
		case '>':
			status.volshape = volFadeOut;
			break;
		}
	}

	int MusicStringThread::GetPos()
	{
		return lastpos;
	}

	void MusicStringThread::TerminateLoop()
	{
		repeat = 1;
	}

	void MusicStringThread::SkipSubroutineDefinition()
	{
		// simply skip the whole subroutine definition
		int depth = 1;
		do
		{
			char ch = GetChar(false);
			if(ch == '{')
				depth++;
			else if(ch == '}')
				depth--;
		} while(depth);
	}
};#pragma once
#include <string>
#include <stack>
#include <cmath>
#include "Tone.h"
#include "Utility.h"
#include "MusicStringException.h"

using namespace std;

namespace MusStr
{
	enum SpecialChars
	{
		SUBR_SKIP_CHAR = 128	// causes the thread to skip subroutine definition
	};

	class MusicStringThread
	{
		bool lastTickGenerated;	// did last tick generate audio?
		bool finished;			// is it done? 

		string *musstr;	// the music sting that it's being operated on
		string name;	// it's possible to name the thread

		int bpos,		// beginning position
			pos,		// current position in the string
			epos,		// ending position in the string
			lastpos,	// pos of the last character from the buffer
			repeat;		// how many times will it repeat

		int waiting;	// how many threads is this one waiting for

		Tone tone;		// last generated tone

		class MusicString *owner;	// who owns the thread
		MusicStringThread *parent;	// thread that craeated this thread

		float nextUpdate;

		struct Argument
		{
			uint e, p;
			Argument(uint begin, uint end)
			{	p = begin; e = end;		}
			Argument() { e = 0; p = 1; }
			bool Empty() { return p > e; }
		};

		struct ThreadStatus
		{
			float bpm;
			float volume;
			NoteDuration duration;
			int nshift;
			WaveForm wave;
			VolumeShape volshape;
			string soundfont;
			Argument args[32];
		} status;

		float ProcessChar(char ch);

		int CalcN(char letter, char center);

		float GenTone(char note);
		float GenPause();

		void SetDuration(char dur);
		void LoadChord();
		void LoadSubroutine();
		void LoadLoop();
		void LoadBpm();
		void LoadSoundfont();
		void LoadVolume();

		void PerformShift();
		void EvaluateCondition(char type);
		void SetWaveform(char wave);
		void SetVolumeShape(char shape);
		void SkipSubroutineDefinition();

		void LoadArg();	// load one argument into the string buffer

		stack<Argument> buffer;
		char GetChar(bool evalarg = true);	// gets a char from the buffer
		int GetPos();	// gets position of just loaded char

	public:
		MusicStringThread(string *musstr, class MusicString *owner,
			int pos = 0, int epos = -1, ThreadStatus *status = 0,
			MusicStringThread *parent = 0, int repeat = 1, string name = "");

		~MusicStringThread();

		void SubthreadDone(float nextUpdate);
		void TerminateLoop();

		void Tick();		// perform a single step - generate a tone

		bool Active() { return !waiting; }	// does it even have last tone?
		bool Finished() { return finished && !waiting; }
		Tone GetLastTone() { return tone; }	// get the generated tone
		string GetName() { return name; }

		float NextUpdate() {
			return (waiting)?(float)FINF:nextUpdate; }
		void NextUpdate(float subtract) { nextUpdate = Max(0.0f, nextUpdate-subtract); }
	};
}#include "Tone.h"

namespace MusStr
{
	const char *waveFormSymbol = "~-^/|*";
	const char *volumeShapeSymbol = "=<>";

	Tone::Tone()
	{
		freq = time = vol = 0;
		wave = waveSine;
		vshape = volLinear;
		sfont = "";
		pos = -1;
	}

	Tone::Tone(float freq, float time, float vol,
			WaveForm wave, VolumeShape vshape,
			string sfont, uint pos)
	{
		this->freq = freq;
		this->time = time;
		this->vol = vol;
		this->wave = wave;
		this->vshape = vshape;
		this->sfont = sfont;
		this->pos = pos;
	}

	string Tone::GetMusicListEntry()
	{
        return ToStringFixed(freq) + waveFormSymbol[wave] +
            ToStringFixed(vol) + volumeShapeSymbol[vshape] +
            ToStringFixed(time) + '"' + sfont + '"' + ';';
	}

	Tone::Tone(string tone)
	{
		int pos = 0;
		freq = FromString<float>(tone);

		while(tone[pos] == '.' || isdigit(tone[pos]) || isspace(tone[pos]))
			pos++;
		
		for(int i = 0; *(waveFormSymbol+i); ++i)
			if(*(waveFormSymbol+i) == tone[pos])
			{
				wave = (WaveForm)i;
				break;
			}

		// the volume
		vol = FromString<float>(tone.substr(++pos));
		
		while(tone[pos] == '.' || isdigit(tone[pos]) || isspace(tone[pos]))
			pos++;

		for(int i = 0; *(volumeShapeSymbol+i); ++i)
			if(*(volumeShapeSymbol+i) == tone[pos])
			{
				vshape = (VolumeShape)i;
				break;
			}

		// duration
		time = FromString<float>(tone.substr(++pos));

		// soundfont
		tone = tone.substr(tone.find('"')+1);
		sfont = tone.substr(0, tone.find('"'));
	}
}#pragma once
#include <string>
#include "Utility.h"
using namespace std;

namespace MusStr
{
	enum NoteDuration
	{
		note128th,
		note64th,
		note32th,
		note16th,
		note8th,
		note4th,
		note2th,
		note1x,
		note2x,
		note4x
	};

	enum WaveForm
	{
		waveSine,
		waveSquare,
		waveTriangle,
		waveSawtooth,
		wavePluck,
		waveNoise
	};

	enum VolumeShape
	{
		volLinear,
		volFadeIn,
		volFadeOut
	};

	class Tone
	{
		float freq,		// in hertz
			  time,		// in milliseconds
			  vol;	// 0.0 - 1.0
		WaveForm wave;
		VolumeShape vshape;
		string sfont;

		uint pos;	// position of the corresponding character in the string

	public:
		Tone();
		Tone(string tone);
		Tone(float freq, float time, float vol,
			WaveForm wave, VolumeShape vshape,
			string sfont, uint pos);

		inline float GetFreq() { return freq; }
		inline float GetDuration() { return time; }
		inline float GetVolume() { return vol; }
		inline float GetShape(float progress)
		{
			switch(vshape)
			{
			case volLinear:
				return 1.0f;
			case volFadeIn:
				return progress*progress;
			case volFadeOut:
				return (1.0f-progress)*(1.0f-progress);
			}
			return 0.0f;	// make compiler happy
		}
		inline WaveForm GetWaveForm() { return wave; }

		string GetMusicListEntry();
	};
}/*
	Some global stuff, that's shared by most files
*/
#pragma once
#include <cmath>
#include <string>
#include <sstream>
#include <iostream>
#include <iomanip>

typedef unsigned char byte;
typedef unsigned long long ull;
typedef unsigned int uint;
typedef unsigned short ushort;

typedef byte reg8;
typedef ushort reg16;
typedef uint reg32;
typedef ull reg64;

template <typename X> inline X SetBit(X val, uint bit, bool set)
{
	val &= ~(((X)1)<<bit);
	if(set)
		val |= ((X)1)<<bit;
	return val;
}

template <typename X> inline void SetBit(X *val, uint bit, bool set)
{
	*val = SetBit(*val, bit, set);
}

template <typename X> X FromString(std::string str)
{
	X val;
	std::stringstream ss(str);
	ss >> val;
	return val;
}

template <typename X> std::string ToString(X i)
{
    std::stringstream ss;
	ss << i;
	return ss.str();
}

template <typename X> std::string ToStringFixed(X i)
{
    std::stringstream ss;
    ss << std::fixed << i;
    return ss.str();
}

template <typename X> std::string ToStringHEX(X i, int minwidth)
{
    std::stringstream ss;
	ss << std::hex << std::setfill('0') << std::setw(minwidth) << i;
	return ss.str();
}

template <typename X> X FromHEXString(std::string str)
{
	X val;
	std::stringstream ss;
	ss << std::hex << str;
	ss >> val;
	return val;
}

inline std::string substrBetween(std::string str, int from, int to)
{
	return str.substr(from, to-from);
}

inline std::string StripSpaces(std::string str)
{
	std::string out;
	for(uint i = 0; i < str.length(); ++i)
		if(!isspace(str[i]))
			out += str[i];
	return out;
}

inline float FLOAT(uint data)
{
	union
	{
		float f;
		uint i;
	} convert;
	convert.i = data;
	return convert.f;
}

inline uint UINT(float data)
{
	union
	{
		float f;
		uint i;
	} convert;
	convert.f = data;
	return convert.i;
}

template <typename X> inline X Min(X a, X b)
{
	return (a<b)?a:b;
}

template <typename X> inline X Max(X a, X b)
{
	return (a>b)?a:b;
}

template <typename X> inline X logN(X val, X base)
{
	return log(val)/log(base);
}

template <typename X> inline X rotate(X val, int shift)
{
	if(shift == 0)
		return val;
	if(shift > 0)
	{
		shift %= sizeof(X)*8;	// limit the shift value
		return (val << shift) | (val >> (8*sizeof(X)-shift));
	}
	if(shift < 0)
	{
		shift = -shift;	// negate it
		shift %= sizeof(X)*8;	// limit the shift value
		return (val >> shift) | (val << (8*sizeof(X)-shift));
	}

	// make compiler happy...
	return 0;
}

class reg4
{
	reg8 data;	// uses 16 bit register for storage

public:
	reg4() { data = 0; }

	reg8 operator=(uint newval)
	{
		return data = newval & 0x0FU;	// allow only first 5 bits
	}

	reg8 operator++()
	{
		return *this = ++data;
	}

	reg8 operator++(int bogus)
	{
		reg8 temp = data;
		*this = ++data;
		return temp;
	}

	reg8 operator--()
	{
		return *this = --data;
	}

	reg8 operator--(int bogus)
	{
		reg8 temp = data;
		*this = --data;
		return temp;
	}

	reg8 operator+=(uint val)
	{
		return *this = data + val;
	}

	reg8 operator-=(uint val)
	{
		return *this = data - val;
	}

	operator reg8()
	{
		return data;
	}
};

class reg5
{
	reg16 data;	// uses 16 bit register for storage

public:
	reg5() { data = 0; }
	reg5(uint data) { this->data = data&0x1FU; } 

	reg16 operator=(uint newval)
	{
		return data = newval & 0x1FU;	// allow only first 5 bits
	}

	reg16 operator++()
	{
		return *this = ++data;
	}

	reg16 operator++(int bogus)
	{
		reg16 temp = data;
		*this = ++data;
		return temp;
	}

	reg16 operator--()
	{
		return *this = --data;
	}

	reg16 operator--(int bogus)
	{
		reg16 temp = data;
		*this = --data;
		return temp;
	}

	reg16 operator+=(uint val)
	{
		return *this = data + val;
	}

	reg16 operator-=(uint val)
	{
		return *this = data - val;
	}

	operator reg16()
	{
		return data;
	}
};

class reg24
{
	reg32 data;	// uses 16 bit register for storage

public:
	reg24() { data = 0; }

	reg32 operator=(uint newval)
	{
		return data = newval & 0xFFFFFFU;	// allow only first 5 bits
	}

	reg32 operator++()
	{
		return *this = ++data;
	}

	reg32 operator++(int bogus)
	{
		reg32 temp = data;
		*this = ++data;
		return temp;
	}

	reg32 operator--()
	{
		return *this = --data;
	}

	reg32 operator--(int bogus)
	{
		reg32 temp = data;
		*this = --data;
		return temp;
	}

	reg32 operator+=(uint val)
	{
		return *this = data + val;
	}

	reg32 operator-=(uint val)
	{
		return *this = data - val;
	}

	operator reg32()
	{
		return data;
	}
};

template <typename X> inline bool Bit(X val, byte bit)
{
	return (val >> bit)&1;
}

template <typename X> inline bool Between(X val, X min, X max)
{
	return (val >= min) && (val <= max);
}

const double FZERO = 0.0;
const double FINF = 1.0/FZERO;
const double FNAN = FZERO/FZERO;
const double PI = 3.14159265358979323846264338327950288;	// is this enough precision? x3
const double PI_HALF = PI/2.0;

inline bool isinf(float val)
{
	return val == FINF;
}

inline bool isnan(float val)
{
	return !(val == val);
}